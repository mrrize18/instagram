# Custom Caption Command :

  *{target}		: Username Target Repost

  *{originalCaption}	: Original Caption Dari Target

  *{me}			: Username IG yg digunakan untuk repost

# Thanks To :
 *Code by Ccocot (ccocot@bc0de.net)
 
 *SGB TEAM REBORN
 
 *RMT BY Mas Okky (@masokky_)
