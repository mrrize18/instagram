# [⚡] DEFAULT or BASIC USAGE ☑
	* git clone https://github.com/officialputuid/toolsig.git
	* cd toolsig
	* unzip node_modules.zip
	* node index.js
	* Then select the tool you want to use!

# [♯] For TERMUX ☑
	* Install Termux (PlayStore)
	* Open Termux and Wait for Automatic Install of Termux.
	* pkg install git
	* pkg install nodejs-lts
	* git clone https://github.com/officialputuid/toolsig.git
	* cd toolsig
	* unzip node_modules.zip
	* node index.js
	* Then select the tool you want to use!

# [♯] For LAPTOP/PC ☑
	* Download GIT for Windows		(https://git-scm.com/download/) *Choose WIN & 32bit/64bit
	* Download NodeJS			(https://nodejs.org/en/download/) *Choose .msi & 32bit/64bit
	* Install GIT for Windows & NodeJS
	* Download File on Github		(https://github.com/officialputuid/toolsig.git)
	* Extract File toolsig-master and enter the folder
	* Right Click on Mouse, Then Select "Git Bash Here" (Make sure you are in the toolsig folder!)
	* Then type: unzip node_modules.zip
	* To View The Contents Of a folder in bash, type: "ls" (without "")
	* To Run The Program in bash, type: "node index.js" (without "")
	* Then select the tool you want to use!

# [♯] For OTHER APP (C9.io/CodeAnywhere) ☑
	* Create a Project & User Feature/Template NodeJs on Your Other Application C9io or CodeAnywhere.
	* Use SSH Github : git@github.com:officialputuid/toolsig.git
	* Unzip node_modules.zip
	* nvm install 10.0.0
	* nvm use 10.0.0
	* nvm alias default 10.0.0
	* node index.js
	* Then select the tool you want to use!

# [✭] FEATURES & INFORMATION TOOLS ☑
	* [-] BomLikeTarget		"LIKE/LOVE ALL MEDIA/POST USER"
	* [-] Botlike1			"LIKE/LOVE TIMELINE INSTAGRAM"
	* [-] Botlike2			"LIKE/LOVE TIMELINE INSTAGRAM"
	* [-] Dellallphoto		"DELETE ALL MEDIA/POST INSTAGRAM"
	* [-] Fah			"FOLLOW,LIKE,COMMENT TARGET HASTAG"
	* [-] Fftauto			"FOLLOW,LIKE,COMMENT TARGET FOLLOWER USER"
	* [-] Flaauto			"FOLLOW,LIKE,COMMENT TARGET LOCATION"
	* [-] Flmauto			"FOLLOW,LIKE,COMMENT TARGET MEDIA/POST"
	* [-] Unfollall			"UNFOLOW ALL FOLLOWING INSTAGRAM"
	* [-] Unfollnotfollback		"UNFOLLOW NOT FOLLOWBACK INSTAGRAM"

# [!] WARNING
	"Use tools at your own risk!"
	"Use this Tool for personal use, not for sale!"
	"I am not responsible for your account using this tool."
	"Make sure your account has been verified (email and telephone number)"

# [☩] UPDATE
	* Update Instagram API [NEW]
	* Fix Error No Detect Followers Target
	* Fix Error UNFB [No Detect List Unfoll]
	* Input Total of Target You Want (ITTYW)
	* Improvements In Display Program
	   
# [✭] SPECIAL THANKS TO
	* Code by Ccocot (ccocot@bc0de.net)
	* SGB TEAM REBORN | Zerobyte.id | BC0DE.NET | NAONLAH.NET - WingKocoli
	* ADDING FEATURES (ITTYW) by Putu Jaya Adi Pranata (@officialputuid)
